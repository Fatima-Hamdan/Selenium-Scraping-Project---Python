from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
import csv



List_Days = ["%.2d" % i for i in range(10,32)]
print(List_Days)

csv_file = open('Flights_Paris2.csv', 'w')
writer = csv.writer(csv_file)

for Day in List_Days:

	driver= webdriver.Chrome('C:/Users/USER/Downloads/chromedriver_win32/chromedriver.exe')

	driver.get('https://www.kayak.com/flights/CDG-DXB/2018-03-%s?sort=bestflight_a' %Day) 
	time.sleep(10)
	webdriver.ActionChains(driver).send_keys(Keys.ESCAPE).perform()
	#time.sleep(5)

	
	#Show_More_Results_Button = WebDriverWait(driver,10).until(EC.element_to_be_clickable((By.XPATH,'//div[class="Common-Results-Paginator ButtonPaginator visible"]')))
	#Show_More_Results_Button.click()

	index= 0

	while True:
		try:

			index = index+1
			flights= driver.find_elements_by_xpath('//div[@page-idx="%s"]' %index)
			print(index)
			print(len(flights))

			for flight in flights:

				flights_dict= {}

				One_Way = driver.find_element_by_xpath('.//div[@data-value="oneway"]').text
				Class = driver.find_element_by_xpath('.//div[@data-value="e"]').text
				#Departure_City = driver.find_element_by_xpath('.//div[@class="_bVp _bv _bF _hS _bVr _oW"]').text
				#Destination_City = driver.find_element_by_xpath('.//div[@class="_RE _eJ _v _bU- _w _y _k6 _Lg _h6 _h5 _hZ _RF _Sg _Re _qg _bX _si _Sh _qf _RG _qj _QN _bVd _s _Si _Sk _Sj _Sm _Sl _So _Sn _h3 _Sp _bVe _N _r3 _bVi"]').text
				#Date_of_Departure = driver.find_element_by_xpath('.//div[@class="_bv _bF _bM3 _hS _i8 _r3 _bM5"]').text

				Departure_City = driver.find_element_by_xpath('.//div[@class="_LB _eJ _v _w _y _bVY _k6 _R0 _qr _Q9 _h6 _h5 _SC _RA _hZ _sE _SD _bV2 _bX _qo _qn _R2 _R1 _SE _SG _SF _s _SI _SH _SK _SJ _SL _h3 _bV3 _N _bV7 _so"]').text
				Destination_City = driver.find_element_by_xpath('.//div[@class="_LB _eJ _v _w _y _bVY _k6 _R0 _qr _Q9 _h6 _h5 _SC _RA _hZ _sE _SD _bV2 _bX _qo _qn _R2 _R1 _s _SM _SO _SN _SQ _SP _bV4 _SS _m _SR _bV7 _so"]').text
				Date_of_Departure = driver.find_element_by_xpath('.//div[@class="_bv _bF _hS _i8 _bNN _bNP _so"]').text

				#Cheapest_Price = flight.find_element_by_xpath('.//div[@class="bottom"]').text
				#Fastest_Price = flight.find_element_by_xpath('.//div[@class="bottom"]').text
				#Best_Experience_Price = flight.find_element_by_xpath('.//div[@class="bottom"]').text

				Airlines_Name = flight.find_element_by_xpath('.//div[@class="col-field carrier"]').text
				Departure_Airport = flight.find_element_by_xpath('.//div[@class="col-field time depart"]/div[2]').text
				Departure_Time = flight.find_element_by_xpath('.//div[@class="col-field time depart"]/div[1]').text
				Arrival_Airport = flight.find_element_by_xpath('.//div[@class="col-field time return"]/div[2]').text
				Arrival_Time = flight.find_element_by_xpath('.//div[@class="col-field time return"]/div[1]').text

				try:
					Number_of_Extra_Days = flight.find_element_by_xpath('.//span[@title="Flight lands the next day"]').text	
				except NoSuchElementException:
					Number_of_Extra_Days = 0

				Total_Duration_Flight = flight.find_element_by_xpath('.//div[@class="col-field duration"]').text
				Direct_StopOvers_Flights =  flight.find_element_by_xpath('.//div[@class="col-field stops"]/div[2]').text

				Website_Having_the_offer = flight.find_element_by_xpath('.//span[@class="providerName option-text"]').text
				Price_in_Dollars = flight.find_element_by_xpath('.//span[@class="price option-text"]').text

				

				#print(One_Way)
				#print(Departure_City)
				#print(Destination_City)
				#print(Date_of_Departure)
				#print(Class)
				#print('-'*50)

				print(Airlines_Name)
				#print(Departure_Airport)
				#print(Departure_Time)
				#print(Arrival_Airport)
				#print(Arrival_Time)
				#print('-'*50)

				print(Number_of_Extra_Days)
				#print(Total_Duration_Flight)
				#print(Direct_StopOvers_Flights)
				#print(Website_Having_the_offer)
				#print(Price_in_Dollars)
				#print(50*'*')
				flights_dict['widget_index'] = index
				flights_dict['flights_in_widget'] = len(flights)
				flights_dict['One_Way'] = One_Way
				flights_dict['Departure_City'] = Departure_City
				flights_dict['Destination_City'] = Destination_City
				flights_dict['Date_of_Departure'] = Date_of_Departure
				flights_dict['Class'] = Class
				flights_dict['Airlines_Name'] = Airlines_Name
				flights_dict['Departure_Airport'] = Departure_Airport
				flights_dict['Departure_Time'] = Departure_Time
				flights_dict['Arrival_Airport'] = Arrival_Airport
				flights_dict['Arrival_Time'] = Arrival_Time
				flights_dict['Number_of_Extra_Days'] = Number_of_Extra_Days
				flights_dict['Total_Duration_Flight'] = Total_Duration_Flight
				flights_dict['Direct_StopOvers_Flights'] = Direct_StopOvers_Flights
				flights_dict['Website_Having_the_offer'] = Website_Having_the_offer
				flights_dict['Price_in_Dollars'] = Price_in_Dollars
				writer.writerow(flights_dict.values())


			if(len(flights) == 0):
				driver.execute_script("window.scrollTo(0,document.body.scrollHeight - 5);")
				time.sleep(10)
				if(len(flights) == 0):
					pass
					break


	#driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
	#Show_More_Results_Button = driver.find_element_by_link_text("Show more results")
	#Show_More_Results_Button = driver.find_element_by_xpath('//a[@class="moreButton"]')
	#driver.execute_script("arguments[0].scrollIntoView(true);", driver.find_element_by_xpath('//a[@class="moreButton"]'))
	#wait_button = WebDriverWait(driver, 10)
			if(index == 1):

				Show_More_Results_Button = WebDriverWait(driver, 10).until(EC.element_to_be_clickable((By.XPATH,'//a[@class="moreButton"]')))
				Show_More_Results_Button.click()
				time.sleep(10)
				print('doneeee'*50)

			else:
				driver.execute_script("window.scrollTo(0,document.body.scrollHeight - 10);")
				time.sleep(10)


		#driver.execute_script("arguments[0].scrollIntoView(true);", Show_More_Results_Button)
		#time.sleep(2)
		except Exception as e:
			print(e)
			csv_file.close()
			driver.close()
			break
		
		