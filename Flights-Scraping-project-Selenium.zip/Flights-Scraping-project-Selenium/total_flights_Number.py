from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.keys import Keys
import csv



List_Days = ["%.2d" % i for i in range(1,32)]
print(List_Days)
#'HKG','AMS','CDG','SIN','ICN','FRA',
List_Airports = ['BKK','TPE','ATL']

csv_file = open('Total_FlightsTest.csv', 'w')
writer = csv.writer(csv_file)

Total_Number_of_Flights_Dict = {}

for Airport in List_Airports:
	try:
		for Day in List_Days:

			driver= webdriver.Chrome('C:/Users/USER/Downloads/chromedriver_win32/chromedriver.exe')

			driver.get('https://www.kayak.com/flights/%s-DXB/2018-03-%s?sort=bestflight_a' % (Airport,Day)) 
			time.sleep(5)
			webdriver.ActionChains(driver).send_keys(Keys.ESCAPE).perform()
			#time.sleep(10)

	
			Departure_City = driver.find_element_by_xpath('.//div[@class="_bVp _bv _bF _hS _bVr _oW"]').text
			Destination_City = driver.find_element_by_xpath('.//div[@class="_RE _eJ _v _bU- _w _y _k6 _Lg _h6 _h5 _hZ _RF _Sg _Re _qg _bX _si _Sh _qf _RG _qj _QN _bVd _s _Si _Sk _Sj _Sm _Sl _So _Sn _h3 _Sp _bVe _N _r3 _bVi"]').text
			Total_Number_of_Flights = driver.find_element_by_xpath('.//div[@class="Common-Results-DisplayCounts simple visible"]/a/span[1]').text
			Filtered_Flights= driver.find_element_by_xpath('.//div[@class="Common-Results-DisplayCounts simple visible"]/span[1]').text

			Total_Number_of_Flights_Dict['Departure_City'] = Departure_City
			Total_Number_of_Flights_Dict['Destination_City'] = Destination_City
			Total_Number_of_Flights_Dict['Total_flights_number'] = Total_Number_of_Flights
			Total_Number_of_Flights_Dict['Filtered_Flights'] = Filtered_Flights
			Total_Number_of_Flights_Dict['Day'] = Day



			print(Departure_City)
			print(Destination_City)
			print(Total_Number_of_Flights)
			print(Filtered_Flights)
			writer.writerow(Total_Number_of_Flights_Dict.values())


		

	except Exception as e:
		print(e)
		csv_file.close()
		driver.close()
		break
		
		